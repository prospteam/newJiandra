<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <section class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1><b>Dashboard</b></h1>
          HOME > <span class="active1"> DASHBOARD</p>
        </div>
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active">Blank Page</li>
          </ol>
        </div>
      </div>
    </div><!-- /.container-fluid -->
  </section>
  <div class="total_sales">
      <img src="<?php echo base_url('/assets/dist/img/tops.PNG'); ?>" alt="Total Sales">
  </div>
  <div class="top_selling_products">
    <img src="<?php echo base_url('/assets/dist/img/middle.png'); ?>" alt="Total Sales">
  </div>
  <!-- Main content -->
  <section class="content">

    <!-- Default box -->


  </section>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->
